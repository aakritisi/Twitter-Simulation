defmodule TwitterCloneWeb.LayoutViewTest do
  use TwitterCloneWeb.ConnCase, async: true
end
