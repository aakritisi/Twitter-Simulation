defmodule TwitterCloneWeb.PageViewTest do
  use TwitterCloneWeb.ConnCase, async: true
end
