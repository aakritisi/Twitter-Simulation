ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(TwitterClone.Repo, :manual)
