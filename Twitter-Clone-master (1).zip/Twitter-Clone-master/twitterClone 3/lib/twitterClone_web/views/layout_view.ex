defmodule TwitterCloneWeb.LayoutView do
  use TwitterCloneWeb, :view
end
