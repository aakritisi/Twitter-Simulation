defmodule TwitterCloneWeb.PageView do
  use TwitterCloneWeb, :view
end
