# Twitter clone - COP5615 (Fall 2019)
Problem description :- 
In this project we had to implement the clone for twitter with front end capabilities.

# 1. Group Members :-
Akshit Mehta (UFID: 60338721)
Aakriti Singh (UFID: 11399881)

Steps to run the code :- 
1. Change directory to project directory (twitterclone 3)
3. mix ecto.create
4. mix phx.server

# 3. What is working?
We have successfully integrated the previous functionality (project 4.1) to work with the front end.

#4. Link to the video demo 
https://youtu.be/_cS1L3Pskec
